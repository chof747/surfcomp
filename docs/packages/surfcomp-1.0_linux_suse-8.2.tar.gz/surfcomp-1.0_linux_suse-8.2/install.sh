#!/bin/sh

#*******************************************************************************
CHECK_FOR_PACKAGE()
#*******************************************************************************
{
	PACKAGE=$1

	if rpm --query $PACKAGE > /dev/null; then
    echo -n "$PACKAGE installed; "
		echo "version  = `rpm --query $PACKAGE --queryformat '%{VERSION}'`"
	else
		echo "$PACKAGE is missing on this system!"
		exit 1;
	fi
}


#*******************************************************************************
INSTALL_PACKAGE_IF()
#*******************************************************************************
{
	PACKAGE=$1 
  RPMFILE=$2

  VERSION=`rpm --query $PACKAGE --queryformat '%{VERSION}'`
	RPMVERS=`rpm -qp $RPMFILE --queryformat '%{VERSION}'`
	
  if [ "$VERSION" = "$RPMVERS" ]; then
		echo "$PACKAGE is allready installed; version = $VERSION"
	else
		rpm -vh -U $RPMFILE
  fi
}

UNINSTALL_PACKAGE()
{
  PACKAGE=$1

	if rpm --query $PACKAGE > /dev/null; then
    VERSION=`rpm --query $PACKAGE --queryformat '%{VERSION}'`
		
	  echo "removing package $PACKAGE-$VERSION"
    rpm -e $PACKAGE-$VERSION
	fi
}

if [ "`whoami`" != "root" ]; then
  echo "you must be root!"
  exit 1;
fi

if [ "$1" = "-u" ] ; then
	UNINSTALL_PACKAGE surfcomp-control
	UNINSTALL_PACKAGE surfcomp
	UNINSTALL_PACKAGE libsurfcomp
	UNINSTALL_PACKAGE trimesh
	UNINSTALL_PACKAGE libsurface
	UNINSTALL_PACKAGE graph-algorithms
	UNINSTALL_PACKAGE bestrot
	UNINSTALL_PACKAGE RazorBack
	UNINSTALL_PACKAGE xmlutils
	
else
	CHECK_FOR_PACKAGE mysql-shared
	CHECK_FOR_PACKAGE Xerces-c
	
	INSTALL_PACKAGE_IF xmlutils xmlutils-1.0.0-1.i386.rpm
	INSTALL_PACKAGE_IF RazorBack RazorBack-2.0.0-1.i386.rpm
	INSTALL_PACKAGE_IF bestrot bestrot-1.0.0-1.i386.rpm
	INSTALL_PACKAGE_IF graph-algorithms graph-algorithms-1.0.0-1.i386.rpm
	INSTALL_PACKAGE_IF libsurface libsurface-1.1.0-1.i386.rpm
	INSTALL_PACKAGE_IF trimesh trimesh-1.0.0-1.i386.rpm
	INSTALL_PACKAGE_IF libsurfcomp libsurfcomp-1.0.0-1.i386.rpm
	INSTALL_PACKAGE_IF surfcomp surfcomp-1.0.0-1.i386.rpm
	INSTALL_PACKAGE_IF surfcomp-control surfcomp-control-1.0.0-1.i386.rpm
fi

#!/bin/sh

#*******************************************************************************
CHECK_FOR_PACKAGE()
#*******************************************************************************
{
	PACKAGE=$1

	if rpm --query $PACKAGE > /dev/null; then
    echo -n "$PACKAGE installed; "
		echo "version  = `rpm --query $PACKAGE --queryformat '%{VERSION}'`"
	else
		echo "$PACKAGE is missing on this system!"
		exit 1;
	fi
}

#*******************************************************************************
REBUILD()
#*******************************************************************************
{
	SRCRPM=$1
	WROTES=`rpmbuild --rebuild $SRCRPM | grep "^Wrote:"`

	RPMS=`echo $WROTES | sed -e 's/Wrote://g'`
 
  for rpmfile in $RPMS; do
    NAME=`basename $rpmfile .rpm | sed -e 's/-[0-9]\.[0-9]\.[0-9]-.*//'`

    #devel package, needed for installation only
		if echo $rpmfile | egrep -sq "\-devel"; then
		  rpm -i $rpmfile
			INSTALLED_RPMS=" $NAME $INSTALLED_RPMS"
		else 
			if echo $rpmfile | egrep -sq "\-doc"; then
      dummy=42
			
			else
		    rpm -i $rpmfile
			  INSTALLED_RPMS="$NAME $INSTALLED_RPMS"
			  cp $rpmfile $REPOSITORY
				
				PKG_FILE=`basename $rpmfile`
				PKG_INSTALL="$PKG_INSTALL\\n\\tINSTALL_PACKAGE_IF $NAME $PKG_FILE"
				PKG_UNINSTALL="UNINSTALL_PACKAGE $NAME\\n\\t$PKG_UNINSTALL"
		  fi
    fi
  done
}

#*******************************************************************************
BUILD_INSTALL()
#*******************************************************************************
{
	echo $PKG_INSTALL
	echo $PKG_UNINSTALL

	cp install.sh.in $REPOSITORY/install.sh
  sed -e "s/@INSTALL@/$PKG_INSTALL/" $REPOSITORY/install.sh > temp
	sed -e "s/@UNINSTALL@/$PKG_UNINSTALL/"  temp > $REPOSITORY/install.sh
	rm temp
	chmod a+x $REPOSITORY/install.sh

	cp README.in $REPOSITORY/README
}

if [ "`whoami`" != "root" ]; then
  echo "you must be root!"
  exit 1;
fi

#READ COMMAND LINE PARAMETERS
#-------------------------------------------------------------------------------
if [ "x$1" = "x" ]; then 
	REPOSITORY=./rpms
else
	REPOSITORY=$1
fi

#PREPARE VARIABLES
#-------------------------------------------------------------------------------
INSTALLED_RPMS=
PKG_INSTALL=
PKG_UNINSTALL=

#REBUILD
#-------------------------------------------------------------------------------
mkdir $REPOSITORY

CHECK_FOR_PACKAGE mysql-shared
CHECK_FOR_PACKAGE mysql-devel
CHECK_FOR_PACKAGE Xerces-c
CHECK_FOR_PACKAGE Xerces-c-devel

REBUILD xmlutils-1.0.0-1.src.rpm
REBUILD RazorBack-2.0.0-1.src.rpm
REBUILD bestrot-1.0.0-1.src.rpm
REBUILD graph-algorithms-1.0.0-1.src.rpm
REBUILD libsurface-1.1.0-1.src.rpm
REBUILD trimesh-1.0.0-1.src.rpm
REBUILD libsurfcomp-1.0.0-1.src.rpm
REBUILD surfcomp-1.0.0-1.src.rpm
REBUILD surfcomp-control-1.0.0-1.src.rpm

#FINISH INSTALLATION FILES AND DEINSTALL PACKAGES
#-------------------------------------------------------------------------------
BUILD_INSTALL

for uninst_rpm in $INSTALLED_RPMS; do
  rpm -e $uninst_rpm
done